﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viewer_lab_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //весь код ниже будет выполнен только после нажатия на кнопку
        //open_img_but_Click это я переименовал, по умолчанию после добавления 1-й кнопки
        //этот метод формы будет называться Button1_Click вроде так
        private void open_img_but_Click(object sender, EventArgs e)
        {
            //фильтр = "описаниефильтра|маскa1;маска2;....маскаN;|описание2.....";
            //ниже устанавливается фильтр для типов отображаемых файлов в проводнике при выборе файла с картинкой
            openFileDialog1.Filter = "Только изображения (*.BMP;*.JPG;*.GIF)|*.BMP;*JPG;*.GIF|Все файлы (*.*)|(*.*)";

            //выполнение кода ниже будет только после выбора картинки
            if (openFileDialog1.ShowDialog() == DialogResult.OK) 
            {
                /*
                 * try
                 * { / участок кода, где может произойти ошибка / }
                 * catch
                 * { / участок кода, который выполнится в случае возникновения ошибки / }
                 */
                try
                {
                    image_box.Image = Image.FromFile(openFileDialog1.FileName);
                    //openFileDialog1 - некий объект, у которого есть поля(переменные и функции)
                    //его поле FileName - знает полное имя файла, который был выбран пользователеме
                    //в метод Image.FromFile передаём это имя (т.е. имя файла с картинкой)
                    //метод "возвращает" картинку
                    //эту картинку записываем в поле Image другого объекта - image_box
                    //результат будет виден на экране. (если ошибок не произошло)
                }
                catch
                {   
                    //вывод сообщения на экран в случае ошикби
                    //Метод (функция) Show объекта MessageBox выведет на экран текст из красной строки
                    MessageBox.Show("Выбранный файл не является изображением. Выберите другой файл.");
                }
            }
            else //эта часть кода, если файл не выбрали и проводник закрыли
                MessageBox.Show("Окно было закрыто");

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void image_box_Click(object sender, EventArgs e)
        {

        }
    }
}
