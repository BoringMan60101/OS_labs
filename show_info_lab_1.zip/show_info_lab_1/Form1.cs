﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace show_info_lab_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //код обработки нажатия на кнопку "Show variable value"
        private void button1_Click(object sender, EventArgs e) 
        {
            //get_txt_box - это объект, у него есть поле Text, которое хранит введённый текст
            //get_txt_box я так сам переименовал, по умолчанию это элемент (TextBox)
            string var_name = get_txt_box.Text; //получили введённый текст

            //ниже в текстовую переменную записывается значение соотвествующей переменной окружения
            string var_val = Environment.GetEnvironmentVariable(var_name); 
            if (var_val != null) //проверка, введено ди коректное имя переменной окружения
            {
                output_txt_box.Text = var_val; //output_txt_box это второй TextBox я просто так его назвал
                //вручную очищать output_txt_box.Text не нужно
                //данные в output_txt_box.Text обновляются сами после ввода правильного имени следующей переменной
                var_list.Items.Add(get_txt_box.Text); //добавление имени выведенной переменной в список (listBox) 
            }
            else
            {
                MessageBox.Show("Error! Unknown variable name."); //на случай не правильного имени переменной окружения
            }

        }

        private void var_list_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
